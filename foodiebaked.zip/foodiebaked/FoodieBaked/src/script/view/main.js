import '../component/foodies-list.js';
import '../component/search-bar.js';
import DataSource from '../data/data-source.js';

const main = () => {
  const searchElement = document.querySelector('search-bar');
  const foodiesListElement = document.querySelector('foodies-list');

  const onButtonSearchClicked = async () => {
    try {
      const result = await DataSource.searchFoodies(searchElement.value);
      renderResult(result);
    } catch (message) {
      fallbackResult(message);
    }
  };

  const renderResult = results => {
    foodiesListElement.foodies = results;
  };

  const fallbackResult = message => {
    foodiesListElement.renderError(message);
  };

  searchElement.clickEvent = onButtonSearchClicked;
};

export default main;
